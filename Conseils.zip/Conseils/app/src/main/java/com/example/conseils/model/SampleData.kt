package com.example.conseils.model

import com.example.conseils.R

val conseilsList = listOf(
    Conseil(1, "Breathe Deeply", "Feel the rhythm of your breath. Let go of tension with each exhale.", R.drawable.day1),
    Conseil(2, "Walk in Rain", "Let the rain wash away stress. Walk slowly, listen to the drops.", R.drawable.day2),
    Conseil(3, "Morning Coffee Ritual", "Savor your coffee. No phone. Just warmth, steam, and quiet.", R.drawable.day3),
    Conseil(4, "Nature’s Heart", "A heart-shaped tree? Nature reminds us: love is everywhere.", R.drawable.day4),
    Conseil(5, "Glowing Waves", "Blue bioluminescence on the beach. Magic exists — even at night.", R.drawable.day5),
    Conseil(6, "Mountain Path", "Every step forward is progress. Even if it’s slow. Keep going.", R.drawable.day6),
    Conseil(7, "Digital Detox", "Put the laptop down. Your mind needs space more than screens.", R.drawable.day7),
    Conseil(8, "Urban Skyline", "Look up. Cities are full of stories — yours is one of them.", R.drawable.day8),
    Conseil(9, "Golden Sunset", "The sky paints itself every evening. Pause. Watch. Breathe.", R.drawable.day9),
    Conseil(10, "City Lights", "Even in chaos, there’s beauty. Find your calm in the crowd.", R.drawable.day10),
    Conseil(11, "Ocean Waves", "Let the waves remind you: some things can’t be controlled — and that’s okay.", R.drawable.day11),
    Conseil(12, "Skincare Moment", "Your skin deserves care. Gentle touch, quiet time, self-love.", R.drawable.day12),
    Conseil(13, "Red Roses at Night", "Beauty doesn’t need daylight. Sometimes darkness makes it glow.", R.drawable.day13),
    Conseil(14, "Park Bench", "Sit. Listen. People-watch. Life unfolds when you stop rushing.", R.drawable.day14),
    Conseil(15, "Cozy Life ", "Earn money every day. Make it your daily goal.", R.drawable.day15),
    Conseil(16, "Sunrise Over Hills", "New day, new light. You’re still here — that’s already a win.", R.drawable.day16),
    Conseil(17, "Cat in Sunbeam", "Be like the cat: nap where the light falls. Rest is sacred.", R.drawable.day17),
    Conseil(18, "Notebook by Lake", "Write your thoughts. Water reflects — so should your mind.", R.drawable.day18),
    Conseil(19, "Movie Night", "Popcorn, dim lights, no distractions. Joy lives in simple moments.", R.drawable.day19),
    Conseil(20, "Holy Place", "Wherever you feel peace — that’s your sanctuary. Return often.", R.drawable.day20),
    Conseil(21, "Makeup Palette", "Create something beautiful — even if it’s just for you.", R.drawable.day21),
    Conseil(22, "Flower Field", "Life blooms in colors you didn’t expect. Be open to surprises.", R.drawable.day22),
    Conseil(23, "Open Book", "Read slowly. Let ideas sink in. Not everything needs to be rushed.", R.drawable.day23),
    Conseil(24, "Flying Above Clouds", "Rise above worries. You’re capable of seeing the bigger picture.", R.drawable.day24),
    Conseil(25, "Running Free", "Move your body like no one’s watching. Freedom feels like this.", R.drawable.day25),
    Conseil(26, "Work From Home", "Balance work and rest. Your desk doesn’t define your worth.", R.drawable.day26),
    Conseil(27, "Touching Water", "Feel the flow. Let go of what you can’t control — it’s okay.", R.drawable.day27),
    Conseil(28, "Moonlit Garden", "Night isn’t empty — it’s full of quiet magic. Sleep well.", R.drawable.day28),
    Conseil(29, "Colorful Food", "Eat with your eyes first. Joy comes in many flavors.", R.drawable.day29),
    Conseil(30, "Self-Care Box", "You deserve gentle moments. Pamper yourself — no guilt allowed.", R.drawable.day30)
)